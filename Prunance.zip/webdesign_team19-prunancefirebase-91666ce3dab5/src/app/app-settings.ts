export class AppSettings {
    public static WORLD_DATA_TOKEN = 'hVlOrMDAPkgJZuN1apK4h5RwCtDWEAQChzJ2zDUlVXiciIZ6DnGwHSfx2haU';
}
