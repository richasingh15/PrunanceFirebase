import { Component, OnInit, Input, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'app-line-chart',
  templateUrl: './line-chart.component.html',
  styleUrls: ['./line-chart.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LineChartComponent implements OnInit {
  @Input() dataset: any;
  @Input() labels: any;

  public chartType = 'line';

  public chartColors: Array<any> = [
    {
      backgroundColor: 'rgb(124,252,0, .5)',
      borderColor: 'rgb(0,100,0)',
      borderWidth: 2,
    }
  ];

  public chartOptions: any = {
    responsive: true,
    maintainAspectRatio: false
  };

  constructor() { }

  ngOnInit() {
  }
}
