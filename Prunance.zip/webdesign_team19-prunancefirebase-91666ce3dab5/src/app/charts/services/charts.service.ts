import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {map, switchMap} from 'rxjs/operators';
import {of} from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class ChartsService {


    constructor(private http: HttpClient) {
    }

    startDate = '2019-11-01';
    endDate = '2019-11-30';
    apiHistoryUrl = 'https://api.exchangeratesapi.io/history';
    apiLatestUrl = 'https://api.exchangeratesapi.io/latest?base=USD';
    apiTreasury = `https://www.quandl.com/api/v3/datasets/USTREASURY/REALLONGTERM.json?api_key=V7vf-xpfjDpYTHpQ3K6q`;

    getExchangeRates(currency: string) {
        return this.http.get(`${this.apiHistoryUrl}?start_at=${this.startDate}&end_at=${this.endDate}&symbols=${currency}&base=USD`).pipe(
            map((res: any) => res['rates']),
            switchMap((val) => {
                const dataset = [];
                for (const rate in val) {
                    if (val.hasOwnProperty(rate)) {
                        dataset.push({date: rate, value: val[rate][currency]});
                    }
                }
                const sorted = dataset.sort((a, b) => {
                    if (a.date < b.date) {
                        return -1;
                    }
                    if (a.date > b.date) {
                        return 1;
                    }
                    return 0;
                });
                const currencyName = currency;
                const labels = sorted.map(data => data.date);
                const values = sorted.map(data => data.value);
                return of({currencyName, values, labels});
            })
        );
    }

    getUSTreasuryBondRates() {


    }

    getLatestExchangeRates() {
        return this.http.get(this.apiLatestUrl).pipe(
            map((data: any) => {
                const date = data['date'];
                const base = data['base'];
                const rates = data['rates'];
                const dataset = [];
                // const dataset2 = [];

                for (const currency in rates) {
                    if (rates.hasOwnProperty(currency)) {
                        dataset.push({currency: currency, value: rates[currency]});
                    }
                }

                console.log(dataset);

                const valueso = dataset.map(latestRates => latestRates.value);
                // console.log(valueso);
                const labelso = dataset.map(latestRates => latestRates.currency);

                const selectCurrencies = new Array(18, 11, 7, 15, 13);
                for (let i = 0; i < selectCurrencies.length; i++) {
                    const newOutputC = labelso[selectCurrencies[i]];
                    const newOutputV = valueso[selectCurrencies[i]];
                    // console.log(newOutputC);
                    // console.log(newOutputV);
                    dataset.push({currency: newOutputC, value: newOutputV});
                }

                const values = dataset.map(latestRates => latestRates.value).slice(33, 38);
                // console.log(values);

                const labels = dataset.map(latestRates => latestRates.currency).slice(33, 38);
                // console.log(labels);


                console.log(dataset);


                return {date, base, values, labels};


            })
        );
    }
}
