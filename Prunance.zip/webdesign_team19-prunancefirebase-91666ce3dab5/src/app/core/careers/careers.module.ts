import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CareersComponent } from './containers/careers/careers.component';
import { FormsModule } from '@angular/forms';
import { ButtonsModule, InputsModule, TableModule, IconsModule, ModalModule } from 'angular-bootstrap-md';

import * as fromCareers from './store/careers.reducer';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { CareersEffects } from './store/careers.effects';
import { CareersRoutingModule } from './careers-routing.module';
import { SharedModule } from '../../shared/shared.module';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    CareersRoutingModule,
    ModalModule,
    FormsModule,
    ButtonsModule,
    InputsModule,
    IconsModule,
    TableModule,
    StoreModule.forFeature('careers', fromCareers.careersReducer),
    EffectsModule.forFeature([CareersEffects])
  ],
  declarations: [CareersComponent],
  exports: [CareersComponent],
})
export class CareersModule { }
