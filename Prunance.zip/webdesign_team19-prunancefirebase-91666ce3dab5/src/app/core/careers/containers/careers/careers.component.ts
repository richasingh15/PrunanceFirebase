import {Component, OnInit, OnDestroy} from '@angular/core';
import {Store} from '@ngrx/store';
import {AppState} from '../../../../reducers';

import {Subscription, Observable} from 'rxjs';
import {getCareers, getIsLoading} from '../../store/careers.selectors';
import {map, take} from 'rxjs/operators';
import {CareersModalComponent} from '../../../../shared/components/careers-modal/careers-modal.component';
import * as fromCareers from '../../../../core/careers/store/careers.actions';
import {Career} from '../../models/career.model';
import {MDBModalRef, MDBModalService} from 'angular-bootstrap-md';
// import {Careerapplication} from '../../models/careerapplication.model';
// import {ApplicationconfirmationModalComponent} from
// '../../../../shared/components/applicationconfirmation-modal/applicationconfirmation-modal.component';

// import {HttpClient} from '@angular/common/http';

@Component({
    selector: 'app-careers',
    templateUrl: './careers.component.html',
    styleUrls: ['./careers.component.css']
})
export class CareersComponent implements OnInit, OnDestroy {
    isLoading$: Observable<boolean>;
    careers: Career[] | null;
    modalRef: MDBModalRef;

    careersSub: Subscription;

    modalConfig = {
        // backdrop: 'static',
        class: 'modal-dialog-centered',
    };

    lastCareerIndex: number;

    constructor(private modalService: MDBModalService, private store: Store<AppState>) {
    }


    ngOnInit() {
        this.isLoading$ = this.store.select(getIsLoading);

        this.careersSub = this.store.select(getCareers).pipe(
            map((careers: Career[]) => {
                if (!careers) {
                    this.store.dispatch(new fromCareers.CareersQuery());
                }
                return careers;
            })
        )
            .subscribe((careers: Career[]) => {
                if (careers && careers.length !== 0) {
                    const index: number = Number(careers[careers.length - 1]);
                    this.lastCareerIndex = index;
                } else {
                    this.lastCareerIndex = 0;
                }

                this.careers = careers;
            });
    }

    ngOnDestroy() {
        if (this.careersSub) {
            this.careersSub.unsubscribe();
        }
    }

    /* onApplyCareer() {
         this.modalRef = this.modalService.show(CareersModalComponent, this.modalConfig);

         this.modalRef.content.heading = 'Add new customer';
         // this.modalRef.content.customer.id = this.lastCustomerIndex + 1;

         this.modalRef.content.customerData.pipe(take(1)).subscribe((careerData: Career) => {
             this.store.dispatch(new fromCareers.CareersAdded({career: careerData}));
         });
     }*/

    openCareerApplicationModal(career: Career) {
        this.modalRef = this.modalService.show(CareersModalComponent, this.modalConfig);

        this.modalRef.content.heading = 'Apply Now';
        const careerCopy = {
                key: career.key,
                name: career.name || null

            }
        ;
        this.modalRef.content.careerPosition = careerCopy;

        this.modalRef.content.careerData.pipe(take(1)).subscribe((careerData: Career) => {
            this.store.dispatch(new fromCareers.CareerApplied({career: careerData}));
        });
    }

    /*openApplicationConfirmationModal(careerapplication: Careerapplication) {
        this.modalRef = this.modalService.show(ApplicationconfirmationModalComponent, this.modalConfig);

        this.modalRef.content.heading = 'Application Confirmation';
        this.modalRef.content.careerapplication = careerapplication;

        /!*this.modalRef.content.careerData.pipe(take(1)).subscribe((careerData: Career) => {
            this.store.dispatch(new fromCareers.CareerApplied({career: careerData}));
        });*!/
    }*/

    onApplyCareer(career: Career) {
        this.openCareerApplicationModal(career);
    }

}
