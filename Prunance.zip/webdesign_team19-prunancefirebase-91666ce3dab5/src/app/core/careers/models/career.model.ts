export interface Career {
    key?: any;
    name?: string;
    description?: string;
}
