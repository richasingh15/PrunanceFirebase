export interface Careerapplication {
    key?: any;
    applicantname?: string;
    address?: string;
    city?: string;
    state?: string;
    zipcode?: string;
    phonenumber?: string;
    emailid?: string;
}
