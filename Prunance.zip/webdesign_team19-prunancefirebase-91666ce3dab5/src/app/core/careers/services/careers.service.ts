import {Injectable} from '@angular/core';
import {AngularFireDatabase} from '@angular/fire/database';
import {Career} from '../models/career.model';
import {Careerapplication} from '../models/careerapplication.model';
import {of} from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class CareersService {

    constructor(private db: AngularFireDatabase) {
    }


    add(career: Career) {
        const careers = this.db.list(`careers`);
        return careers.push(career);
    }

    addCareers(careers: Career[]) {

        careers.forEach((career: Career) => {
            this.db.list(`careers`).push(career);
        });
    }
  get() {
    return this.db.list(`careers`).snapshotChanges();
  }





  update(career: Career) {
        return of(this.db.object(`careers/` + career.key)
            .update({

                name: career.name,
                description: career.description,
            }));
    }

    delete(career: Career) {
        return this.db.object(`careers/` + career.key).remove();
    }

    saveApplication(careerapplication: Careerapplication) {
        const careers = this.db.list(`applycareer`);
        return careers.push(careerapplication);
    }
}
