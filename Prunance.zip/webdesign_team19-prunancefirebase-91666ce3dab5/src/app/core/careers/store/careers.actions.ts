import { Action } from '@ngrx/store';
import { Career } from '../models/career.model';

export enum CareersActionTypes {
  CAREERS_QUERY = '[Careers] Query',
  CAREERS_LOADED = '[Careers] Fetched',
  CAREERS_ADDED = '[Careers] Added',
  CAREERS_EDITED = '[Careers] Edited',
  CAREERS_DELETED = '[Careers] Deleted',

  CAREER_APPLIED = '[Career] Applied',

  CAREERS_ERROR = '[Careers] Error'
}

export class CareersQuery implements Action {
  readonly type = CareersActionTypes.CAREERS_QUERY;
}

export class CareersLoaded implements Action {
  readonly type = CareersActionTypes.CAREERS_LOADED;

  constructor(public payload: { careers: Career[] }) {}
}

export class CareersAdded implements Action {
  readonly type = CareersActionTypes.CAREERS_ADDED;

  constructor(public payload: { career: Career }) {}
}

export class CareersEdited implements Action {
  readonly type = CareersActionTypes.CAREERS_EDITED;

  constructor(public payload: { career: Career }) {}
}

export class CareersDeleted implements Action {
  readonly type = CareersActionTypes.CAREERS_DELETED;

  constructor(public payload: { career: Career }) {}
}

export class CareerApplied implements Action {
  readonly type = CareersActionTypes.CAREER_APPLIED;

  constructor(public payload: { career: Career }) {}
}

export class CareersError implements Action {
  readonly type = CareersActionTypes.CAREERS_ERROR;

  constructor(public payload: { error: any }) {}
}

export type CareersActions =
  | CareersQuery
  | CareersLoaded
  | CareersAdded
  | CareersEdited
  | CareersDeleted
  | CareerApplied
  | CareersError;
