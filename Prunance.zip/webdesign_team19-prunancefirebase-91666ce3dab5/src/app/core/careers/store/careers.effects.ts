import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { CareersService } from '../services/careers.service';
import { CareersActionTypes } from './careers.actions';
import { switchMap, map, catchError, withLatestFrom } from 'rxjs/operators';
import { Career } from '../models/career.model';

import * as fromCareers from './../store/careers.actions';
import { of } from 'rxjs';
import { Store } from '@ngrx/store';
import { AppState } from '../../../reducers';

@Injectable()
export class CareersEffects {

  constructor(private actions$: Actions, private careersService: CareersService, private store: Store<AppState>) {}

  @Effect()
  query$ = this.actions$.pipe(
    ofType(CareersActionTypes.CAREERS_QUERY),
    withLatestFrom(this.store.pipe()),
    switchMap(() => this.careersService.get()
      .pipe(
        map((data: any) => {
          const careersData: Career[] = data.map((res: any) => {
            const key = res.payload.key;
            const career: Career = res.payload.val();
            return {
              key: key,
              name: career.name,
              description: career.description
            };
          });
          return (new fromCareers.CareersLoaded({ careers: careersData }));
        }),
        catchError(error => {
          return of(new fromCareers.CareersError({ error }));
        })
      )
    ),
  );


}
