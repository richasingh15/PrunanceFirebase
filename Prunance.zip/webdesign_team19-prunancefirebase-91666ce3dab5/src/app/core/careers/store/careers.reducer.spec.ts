import { careersReducer } from './careers.reducer';
import { careersInitialState } from './careers.state';

describe('Careers Reducer', () => {
  describe('an unknown action', () => {
    it('should return the previous state', () => {
      const action = {} as any;

      const result = careersReducer(careersInitialState, action);

      expect(result).toBe(careersInitialState);
    });
  });
});
