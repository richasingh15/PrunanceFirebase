import { careersInitialState, CareersState } from './careers.state';
import { CareersActions, CareersActionTypes } from './careers.actions';

export function careersReducer(state = careersInitialState, action: CareersActions): CareersState {
  switch (action.type) {

    case CareersActionTypes.CAREERS_QUERY: {
      return Object.assign({}, state, {
        isLoading: true,
      });
    }

    case CareersActionTypes.CAREERS_LOADED: {
      return Object.assign({}, state, {
        careers: action.payload.careers,
        isLoading: false,
      });
    }

    case CareersActionTypes.CAREERS_ERROR: {
      return Object.assign({}, state, {
        isLoading: false,
        error: action.payload.error
      });
    }

    default:
      return state;
  }
}
