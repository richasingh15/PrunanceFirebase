import { createSelector, createFeatureSelector } from '@ngrx/store';
import { CareersState } from './careers.state';

export const getCareersState = createFeatureSelector<CareersState>('careers');

export const getCareers = createSelector(
  getCareersState,
  careers => careers.careers
);

export const getIsLoading = createSelector(
  getCareersState,
  careers => careers.isLoading
);

export const getError = createSelector(
  getCareersState,
  careers => careers.error
);
