import { Career } from '../models/career.model';

export interface CareersState {
    careers: Career[] | null;
    isLoading: boolean;
    error: any;
}

export const careersInitialState: CareersState = {
    careers: null,
    isLoading: true,
    error: null
};
