import {Component, OnInit} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {getWatchLists} from '../../watch-list/store/watch-list.selectors';
import {map, take} from 'rxjs/operators';
import {WatchList} from '../../watch-list/models/watch-list.model';
import * as fromWatchLists from '../../watch-list/store/watch-list.actions';
import {Subscription} from 'rxjs';
import {Store} from '@ngrx/store';
import {AppState} from '../../reducers';
import {AngularFireAuth} from '@angular/fire/auth';
import {WatchListsModalComponent} from '../../shared/components/watch-lists-modal/watch-lists-modal.component';
import {ConfirmModalComponent} from '../../shared/components/confirm-modal/confirm-modal.component';
import {MDBModalRef, MDBModalService} from 'angular-bootstrap-md';
import {AppSettings} from '../../app-settings';


@Component({
    selector: 'app-main',
    templateUrl: './main.component.html',
    styleUrls: ['./main.component.scss']
})
export class MainComponent implements OnInit {
    httpObj: any;
    indexKeys: any;
    sensexValues: any;
    marketData: any;
    flag: boolean;
    today52weekhigh: any;
    yest52weekhigh: any;
    todayhighdate: any;
    todayhighnum: any;
    today52weeklow: any;
    yest52weeklow: any;
    todaylowdate: any;
    todaylownum: any;
    absdiffhigh: number;
    absdifflow: number;
    //
    todaybond: any;
    todaybondnum: number;
    todaybonddate: any;
    yestbond: any;
    absdiff: number;
    watchListsSub: Subscription;
    watchLists: WatchList[] | null;
    modalRef: MDBModalRef;
    wlFlaf: boolean;
    modalConfig = {
        class: 'modal-dialog-centered'
    };

    public chartType = 'line';

    public chartDatasets: Array<any>;

    public chartLabels: Array<any>;

    public chartColors: Array<any>;

    public chartOptions: any;

    constructor(http: HttpClient, private store: Store<AppState>, private afAuth: AngularFireAuth, private modalService: MDBModalService) {
        this.httpObj = http;
        this.sensexValues = {
            nasdaq: '',
            bse: '',
            nyse: '',
            lse: ''
        };
        this.indexKeys = {
            nasdaq: '^IXIC',
            bse: '^SENSEX',
            nyse: '^NYA',
            lse: '^UKX'
        };
        this.marketData = {
            topCompanies: {},
            data: {}
        };
    }

    ngOnInit() {
        this.flag = false;
        this.wlFlaf = false;
        this.watchListsSub = this.store.select(getWatchLists).pipe(
            map((watchLists: WatchList[]) => {
                if (this.user && !watchLists) {
                    this.store.dispatch(new fromWatchLists.WatchListsQuery());
                }
                return watchLists;
            })
        )
            .subscribe((watchLists: WatchList[]) => {
                if (watchLists) {
                    if (watchLists.length > 0) {
                        this.wlFlaf = true;
                    }
                    console.log(watchLists.length);
                    console.log(watchLists);
                }

                this.watchLists = watchLists;
            });


        this.httpObj.get('https://www.quandl.com/api/v3/datasets/USTREASURY/REALLONGTERM.json'
            +
            '?api_key=V7vf-xpfjDpYTHpQ3K6q')
            .subscribe((resp: any) => {
                this.todaybond = resp.dataset.data[0].toString().substring(11, 15);
                this.todaybondnum = resp.dataset.data[0].toString().substring(11, 15);
                this.todaybonddate = resp.dataset.data[0].toString().substring(0, 10);
                this.yestbond = resp.dataset.data[1].toString().substring(11, 15);
                this.absdiff = Math.round(Math.abs(parseFloat(this.todaybond) - parseFloat(this.yestbond)) * 100);
            });
        this.httpObj.get('https://www.quandl.com/api/v3/datasets/URC/NYSE_52W_HI.json'
            +
            '?api_key=V7vf-xpfjDpYTHpQ3K6q')
            .subscribe((resp: any) => {
                this.today52weekhigh = resp.dataset.data[0].toString().substring(11, 15);
                this.todayhighnum = resp.dataset.data[0].toString().substring(11, 15);
                this.todayhighdate = resp.dataset.data[0].toString().substring(0, 10);
                this.yest52weekhigh = resp.dataset.data[1].toString().substring(11, 15);
                this.absdiffhigh = Math.round(Math.abs(parseFloat(this.today52weekhigh) - parseFloat(this.yest52weekhigh)));
            });
        this.httpObj.get('https://www.quandl.com/api/v3/datasets/URC/NYSE_52W_LO.json'
            +
            '?api_key=V7vf-xpfjDpYTHpQ3K6q')
            .subscribe((resp: any) => {
                this.today52weeklow = resp.dataset.data[0].toString().substring(11, 15);
                this.todaylownum = resp.dataset.data[0].toString().substring(11, 15);
                this.todaylowdate = resp.dataset.data[0].toString().substring(0, 10);
                this.yest52weeklow = resp.dataset.data[1].toString().substring(11, 15);
                this.absdifflow = Math.round(Math.abs(parseFloat(this.today52weeklow) - parseFloat(this.yest52weeklow)));
            });
        this.httpObj.get('https://api.worldtradingdata.com/api/v1/stock?symbol=' +
            this.indexKeys.nasdaq +
            '&api_token=' +
            AppSettings.WORLD_DATA_TOKEN)
            .subscribe((resp: any) => {
                this.sensexValues.nasdaq = resp.data[0];
            });
        this.httpObj.get('https://api.worldtradingdata.com/api/v1/stock?symbol=' +
            this.indexKeys.bse +
            '&api_token=' +
            AppSettings.WORLD_DATA_TOKEN)
            .subscribe((resp: any) => {
                this.sensexValues.bse = resp.data[0];
            });
        this.httpObj.get('https://api.worldtradingdata.com/api/v1/stock?symbol=' +
            this.indexKeys.nyse +
            '&api_token=' +
            AppSettings.WORLD_DATA_TOKEN)
            .subscribe((resp: any) => {
                this.sensexValues.nyse = resp.data[0];
            });
        this.httpObj.get('https://api.worldtradingdata.com/api/v1/stock?symbol=' +
            this.indexKeys.lse +
            '&api_token=' +
            AppSettings.WORLD_DATA_TOKEN)
            .subscribe((resp: any) => {
                this.sensexValues.lse = resp.data[0];
                this.chartLabels = ['', 'Day High', 'Day Low', '52 Weeks High', '52 Weeks Low', 'Price', 'Price Open'];
                this.chartColors = [
                    {
                        backgroundColor: 'rgba(255, 0, 132, .2)',
                        borderColor: 'rgba(200, 99, 132, .7)',
                        borderWidth: 2,
                    },
                    {
                        backgroundColor: 'rgba(105, 255, 132, .2)',
                        borderColor: 'rgba(200, 99, 132, .7)',
                        borderWidth: 2,
                    },
                    {
                        backgroundColor: 'rgba(105, 0, 255, .2)',
                        borderColor: 'rgba(200, 99, 132, .7)',
                        borderWidth: 2,
                    },
                    {
                        backgroundColor: 'rgba(0, 137, 132, .2)',
                        borderColor: 'rgba(0, 10, 130, .7)',
                        borderWidth: 2,
                    }
                ];
                this.chartOptions = {
                    responsive: true
                };
                this.chartDatasets = [
                    {
                        data: [this.sensexValues.nasdaq['day_change'], this.sensexValues.nasdaq.day_high,
                            this.sensexValues.nasdaq.day_low, this.sensexValues.nasdaq['52_week_high'],
                            this.sensexValues.nasdaq['52_week_low'], this.sensexValues.nasdaq.price,
                            this.sensexValues.nasdaq.price_open],
                        label: 'NASDAQ'
                    },
                    {
                        data: [this.sensexValues.bse['day_change'], this.sensexValues.bse.day_high,
                            this.sensexValues.bse.day_low, this.sensexValues.bse['52_week_high'],
                            this.sensexValues.bse['52_week_low'], this.sensexValues.bse.price,
                            this.sensexValues.bse.price_open],
                        label: 'BSE'
                    },
                    {
                        data: [this.sensexValues.nyse['day_change'], this.sensexValues.nyse.day_high,
                            this.sensexValues.nyse.day_low, this.sensexValues.nyse['52_week_high'],
                            this.sensexValues.nyse['52_week_low'], this.sensexValues.nyse.price,
                            this.sensexValues.nyse.price_open],
                        label: 'NYSE'
                    },
                    {
                        data: [this.sensexValues.lse['day_change'], this.sensexValues.lse.day_high,
                            this.sensexValues.lse.day_low, this.sensexValues.lse['52_week_high'],
                            this.sensexValues.lse['52_week_low'], this.sensexValues.lse.price,
                            this.sensexValues.lse.price_open],
                        label: 'LSE'
                    },
                ];
            });
    }

    get user() {
        return this.afAuth.auth.currentUser;
    }

    openEditWatchListModal(watchList: WatchList) {
        this.modalRef = this.modalService.show(WatchListsModalComponent, this.modalConfig);

        this.modalRef.content.heading = 'Edit watch list (watch list item)';
        this.modalRef.content.isEdit = true;
        const watchListCopy = {
            key: watchList.key,
            // id: watchList.id || null,
            name: watchList.name || null,
            description: watchList.description || null,
            symbol: watchList.symbol || null
        };
        this.modalRef.content.watchList = watchListCopy;

        this.modalRef.content.watchListData.pipe(take(1)).subscribe((watchListData: WatchList) => {
            this.store.dispatch(new fromWatchLists.WatchListsEdited({watchList: watchListData}));
        });
    }

    openConfirmModal(watchList: WatchList) {
        this.modalRef = this.modalService.show(ConfirmModalComponent, this.modalConfig);

        this.modalRef.content.confirmation.pipe(take(1)).subscribe((confirmation: boolean) => {
            if (confirmation) {
                this.store.dispatch(new fromWatchLists.WatchListsDeleted({watchList}));
            }
        });
    }

    onWatchListEdit(watchList: WatchList) {
        this.openEditWatchListModal(watchList);
    }

    onWatchListDelete(watchList: WatchList) {
        this.openConfirmModal(watchList);
    }

    setFlag(market: string) {
        this.flag = true;
        if (market === 'nasdaq') {
            this.marketData.data = this.sensexValues.nasdaq;
            this.httpObj.get('https://api.worldtradingdata.com/api/v1/stock_search?stock_exchange=NASDAQ&' +
                'api_token=' +
                AppSettings.WORLD_DATA_TOKEN +
                '&sort_by=market_cap&sort_order=desc')
                .subscribe((resp: any) => {
                    this.marketData.topCompanies = resp.data;
                });
        }
        if (market === 'nyse') {
            this.marketData.data = this.sensexValues.nyse;
            this.httpObj.get('https://api.worldtradingdata.com/api/v1/stock_search?stock_exchange=NYSE&' +
                'api_token=' +
                AppSettings.WORLD_DATA_TOKEN +
                '&sort_by=market_cap&sort_order=desc')
                .subscribe((resp: any) => {
                    this.marketData.topCompanies = resp.data;
                });
        }
        if (market === 'lse') {
            this.marketData.data = this.sensexValues.lse;
            this.httpObj.get('https://api.worldtradingdata.com/api/v1/stock_search?stock_exchange=lse&' +
                'api_token=' +
                AppSettings.WORLD_DATA_TOKEN +
                '&sort_by=market_cap&sort_order=desc')
                .subscribe((resp: any) => {
                    this.marketData.topCompanies = resp.data;
                });
        }
        if (market === 'bse') {
            this.marketData.data = this.sensexValues.bse;
            this.httpObj.get('https://api.worldtradingdata.com/api/v1/stock_search?stock_exchange=bse&' +
                'api_token=' +
                AppSettings.WORLD_DATA_TOKEN +
                '&sort_by=market_cap&sort_order=desc')
                .subscribe((resp: any) => {
                    this.marketData.topCompanies = resp.data;
                });
        }
    }

    unsetFlag() {
        this.flag = false;
    }
}
