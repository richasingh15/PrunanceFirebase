export interface Customer {
    key?: any;
    id?: number;
    name?: string;
    description?: string;
}
