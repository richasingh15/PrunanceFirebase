import {Component, OnDestroy, OnInit} from '@angular/core';
import {MDBModalRef, MDBModalService} from 'angular-bootstrap-md';
import {Store} from '@ngrx/store';
import {AppState} from '../../../reducers';

import * as fromPortfolio from './../../store/portfolio.actions';
import {Equity} from '../../models/equity.model';
import {Observable, Subscription} from 'rxjs';
import {getPortfolio, getIsLoading} from '../../store/portfolio.selectors';
import {map, take} from 'rxjs/operators';
import {AngularFireAuth} from '@angular/fire/auth';
import {EquityBuyModalComponent} from '../../../shared/components/equity-buy-modal/equity-buy-modal.component';
import {EquitySellModalComponent} from '../../../shared/components/equity-sell-modal/equity-sell-modal.component';
import {HttpClient} from '@angular/common/http';
import {AppSettings} from '../../../app-settings';

@Component({
    selector: 'app-portfolio',
    templateUrl: './portfolio.component.html',
    styleUrls: ['./portfolio.component.css']
})
export class PortfolioComponent implements OnInit, OnDestroy {
    isLoading$: Observable<boolean>;
    portfolio: Equity[] | null;
    modalRef: MDBModalRef;

    portfolioSub: Subscription;

    modalConfig = {
        class: 'modal-dialog-centered'
    };

    // lastEquityIndex: number;

    constructor(private httpClient: HttpClient, private modalService: MDBModalService, // private portfolioService: PortfolioService,
                private store: Store<AppState>, private afAuth: AngularFireAuth) {
    }

    ngOnInit() {
        this.isLoading$ = this.store.select(getIsLoading);

        this.portfolioSub = this.store.select(getPortfolio).pipe(
            map((portfolio: Equity[]) => {
                if (this.user && !portfolio) {
                    this.store.dispatch(new fromPortfolio.PortfolioQuery());
                }
                return portfolio;
            })
        )
            .subscribe((portfolio: Equity[]) => {
                /*if (portfolio && portfolio.length !== 0) {
                    const index: number = Number(portfolio[portfolio.length - 1].id);
                    this.lastEquityIndex = index;
                } else {
                    this.lastEquityIndex = 0;
                }*/

                this.portfolio = portfolio;
            });
    }

    get user() {
        return this.afAuth.auth.currentUser;
    }


    ngOnDestroy() {
        if (this.portfolioSub) {
            this.portfolioSub.unsubscribe();
        }
    }

    onBuyEquity() {
        this.modalRef = this.modalService.show(EquityBuyModalComponent, this.modalConfig);

        this.modalRef.content.heading = 'Buy Equity';
        // this.modalRef.content.equity.id = this.lastEquityIndex + 1;

        this.modalRef.content.equityData.pipe(take(1)).subscribe((equityData: Equity) => {
            this.store.dispatch(new fromPortfolio.EquityPurchased({equity: equityData}));
        });
    }

    /*onSellEquity(equity: Equity) {
        if (this.user) {
            if (equity.status !== 'PURCHASED') {
                alert('You are not currently holding this equity');
                return;
            }
            equity.status = 'SOLD';
            this.portfolioService.update(equity, this.user.uid);
            alert('Sold!');
        }
    }*/

    onSellEquity(equity: Equity) {
        this.modalRef = this.modalService.show(EquitySellModalComponent, this.modalConfig);
        this.modalRef.content.equity = equity;
        this.modalRef.content.heading = 'Sell Equity';
        this.modalRef.content.equity = equity;

        this.httpClient.get('https://api.worldtradingdata.com/api/v1/stock?symbol=' +
            equity.symbol +
            '&api_token=' + AppSettings.WORLD_DATA_TOKEN)
            .subscribe((resp: any) => {
                this.modalRef.content.currentPrice = resp.data[0]['price'];

                this.modalRef.content.equityData.pipe(take(1)).subscribe((equityData: Equity) => {
                    this.store.dispatch(new fromPortfolio.EquitySold({equity: equityData}));
                });
            });
    }
}
