import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PortfolioComponent } from './containers/portfolio/portfolio.component';
import { FormsModule } from '@angular/forms';
import { ButtonsModule, InputsModule, TableModule, IconsModule, ModalModule } from 'angular-bootstrap-md';

import * as fromPortfolio from './store/portfolio.reducer';
import * as fromSymbolList from './store/symbol-list.reducer';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { PortfolioEffects } from './store/portfolio.effects';
import { PortfolioRoutingModule } from './portfolio-routing.module';
import { SharedModule } from '../shared/shared.module';


@NgModule({
  declarations: [PortfolioComponent],
  imports: [
    CommonModule,
    SharedModule,
    PortfolioRoutingModule,
    ModalModule,
    FormsModule,
    ButtonsModule,
    InputsModule,
    IconsModule,
    TableModule,
    StoreModule.forFeature('portfolio', fromPortfolio.portfolioReducer),
    StoreModule.forFeature('symbolList', fromSymbolList.symbolListReducer),
    EffectsModule.forFeature([PortfolioEffects])
  ],
  exports: [PortfolioComponent],
})
export class EquityModule { }
