export interface EquitySymbol {
    key?: any;
    currency?: string;
    name?: string;
    stock_exchange_long?: string;
    stock_exchange_short?: string;
    symbol?: string;
}
