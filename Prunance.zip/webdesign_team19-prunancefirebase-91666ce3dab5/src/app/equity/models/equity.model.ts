export interface Equity {
    key?: any;
    symbol?: string;
    pricePerUnit?: number;
    longName?: string;
    volume?: number;
    status?: string;
    sellPricePerUnit?: number;
    purchaseDate?: Date;
    sellDate?: Date;
}
