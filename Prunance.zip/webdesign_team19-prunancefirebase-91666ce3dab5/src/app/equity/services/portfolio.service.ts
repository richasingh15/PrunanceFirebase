import {Injectable} from '@angular/core';
import {AngularFireDatabase} from '@angular/fire/database';
import {Equity} from '../models/equity.model';
import {of} from 'rxjs';
import {AngularFireAuth} from '@angular/fire/auth';
import {map} from 'rxjs/operators';
import {EquitySymbol} from '../models/equity-symbol.model';

@Injectable({
    providedIn: 'root'
})
export class PortfolioService {

    constructor(private db: AngularFireDatabase, private afAuth: AngularFireAuth) {
    }

    get userId() {
        if (this.afAuth.auth.currentUser) {
            return this.afAuth.auth.currentUser.uid;
        }
    }

    add(equity: Equity, userId: string) {
        const portfolio = this.db.list(`portfolio/${userId}`);
        // equity.purchaseDate = new Date();
        return portfolio.push(equity);
    }

    addEquities(equities: Equity[]) {
        const userId = this.userId;

        if (userId) {
            equities.forEach((equity: Equity) => {
                this.db.list(`portfolio/${userId}`).push(equity);
            });
        }
    }

    get(userId: string) {
        return this.db.list(`portfolio/${userId}`).snapshotChanges();
    }

    getAllSymbols() {
        return this.db.list(`symbollist`).snapshotChanges();
    }

    /*getSymbolByNameLike(start: BehaviorSubject<string>, end: BehaviorSubject<string>) {
        return zip(start, end).pipe(switchMap(param => {
            return this.db
                .list('/symbollist/', ref =>
                    ref
                        .limitToFirst(5)
                        .orderByValue()
                        .startAt(param[0].toUpperCase())
                        .endAt(param[1])
                )
                .snapshotChanges()
                .pipe(
                    map((data: any) => {
                        const symbolList: EquitySymbol[] = data.map((res: any) => {
                            const key = res.payload.key;
                            const symbol: EquitySymbol = res.payload.val();
                            return {
                                key: key,
                                value: symbol
                            };
                        });
                        return symbolList;
                    })
                );
        }));
    }*/

    getSymbolByNameLike(term: string) {
        return this.db
            .list('/symbollist/', ref =>
                ref
                    .orderByChild('name')
                    .startAt(term, 'name')
                    .endAt(term + '\uf8ff', 'name')
                    .limitToFirst(5)
            )
            .snapshotChanges()
            .pipe(
                map((data: any) => {
                    // const symbolList: EquitySymbol[] = data.map((res: any) => {
                    const symbolList: EquitySymbol[] = data.map((res: any) => {
                        // const key = res.payload.key;
                        const symbol: EquitySymbol = res.payload.val();
                        /*return {
                            key: key,
                            name: symbol.name
                        };*/
                        symbol.key = res.payload.key;
                        return symbol;
                    }).filter((equitySymbol: EquitySymbol) => equitySymbol.currency === 'USD');
                    return symbolList;
                })
            );
    }

    update(equity: Equity, userId: string) {
        return of(this.db.object(`portfolio/${userId}/` + equity.key)
            .update({
                symbol: equity.symbol,
                longName: equity.longName,
            }));
    }

    sell(equity: Equity, userId: string) {
        return of(this.db.object(`portfolio/${userId}/` + equity.key)
            .update({
                status: equity.status,
                sellDate: equity.sellDate,
                sellPricePerUnit: equity.sellPricePerUnit,
            }));
    }

    delete(equity: Equity, userId: string) {
        return this.db.object(`portfolio/${userId}/` + equity.key).remove();
    }
}
