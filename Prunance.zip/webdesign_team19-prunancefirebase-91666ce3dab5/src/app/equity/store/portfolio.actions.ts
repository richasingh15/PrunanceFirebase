import {Action} from '@ngrx/store';
import {Equity} from '../models/equity.model';
import {EquitySymbol} from '../models/equity-symbol.model';


export enum PortfolioActionTypes {
    PORTFOLIO_QUERY = '[Portfolio] Query',
    SYMBOL_LIST_QUERY = '[SymbolList] Query',
    PORTFOLIO_LOADED = '[Portfolio] Fetched',
    SYMBOL_LIST_LOADED = '[SymbolList] Loaded',

    EQUITY_PURCHASED = '[Equity] Purchased',
    EQUITY_SOLD = '[Equity] Deleted',

    PORTFOLIO_ERROR = '[Portfolio] Error',
    EQUITY_TRANS_ERROR = '[Equity Transaction] Error',
    SYMBOL_LIST_ERROR = '[Symbol List] Error'
}

export class PortfolioQuery implements Action {
    readonly type = PortfolioActionTypes.PORTFOLIO_QUERY;
}

export class SymbolListQuery implements Action {
    readonly type = PortfolioActionTypes.SYMBOL_LIST_QUERY;
}


export class PortfolioLoaded implements Action {
    readonly type = PortfolioActionTypes.PORTFOLIO_LOADED;

    constructor(public payload: { portfolio: Equity[] }) {
    }
}

export class SymbolListLoaded implements Action {
    readonly type = PortfolioActionTypes.SYMBOL_LIST_LOADED;

    constructor(public payload: { symbolList: EquitySymbol[] }) {
    }
}

export class EquityPurchased implements Action {
    readonly type = PortfolioActionTypes.EQUITY_PURCHASED;

    constructor(public payload: { equity: Equity }) {
    }
}

export class EquitySold implements Action {
    readonly type = PortfolioActionTypes.EQUITY_SOLD;

    constructor(public payload: { equity: Equity }) {
    }
}

export class PortfolioError implements Action {
    readonly type = PortfolioActionTypes.PORTFOLIO_ERROR;

    constructor(public payload: { error: any }) {
    }
}

export class SymbolListError implements Action {
    readonly type = PortfolioActionTypes.SYMBOL_LIST_ERROR;

    constructor(public payload: { error: any }) {
    }
}

export class EquityTransError implements Action {
    readonly type = PortfolioActionTypes.EQUITY_TRANS_ERROR;

    constructor(public payload: { error: any }) {
    }
}

export type PortfolioActions =
    PortfolioQuery
    | SymbolListQuery
    | PortfolioLoaded
    | SymbolListLoaded
    | PortfolioError
    | EquityPurchased
    | EquitySold
    | SymbolListError
    | EquityTransError;
