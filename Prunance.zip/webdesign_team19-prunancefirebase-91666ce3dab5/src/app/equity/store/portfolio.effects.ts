import {Injectable} from '@angular/core';
import {Actions, Effect, ofType} from '@ngrx/effects';
import {PortfolioService} from '../services/portfolio.service';
import {PortfolioActionTypes} from './portfolio.actions';
import {switchMap, map, catchError, withLatestFrom} from 'rxjs/operators';
import {Equity} from '../models/equity.model';
import {EquitySymbol} from '../models/equity-symbol.model';

import * as fromPortfolio from './../store/portfolio.actions';
import {of} from 'rxjs';
import {Store, select} from '@ngrx/store';
import {AppState} from '../../reducers';
import {getUser} from '../../auth/store/auth.selectors';

@Injectable()
export class PortfolioEffects {


    constructor(private actions$: Actions, private portfolioService: PortfolioService, private store: Store<AppState>) {
    }

    @Effect()
    query$ = this.actions$.pipe(
        ofType(PortfolioActionTypes.PORTFOLIO_QUERY),
        withLatestFrom(this.store.pipe(select(getUser))),
        switchMap(([, user]: any) => this.portfolioService.get(user.uid)
            .pipe(
                map((data: any) => {
                    const portfolio: Equity[] = data.map((res: any) => {
                        const key = res.payload.key;
                        const equity: Equity = res.payload.val();
                        return {
                            key: key,
                            symbol: equity.symbol,
                            longName: equity.longName,
                            pricePerUnit: equity.pricePerUnit,
                            volume: equity.volume,
                            status: equity.status,
                            purchaseDate: equity.purchaseDate,
                            sellDate: equity.sellDate,
                            sellPricePerUnit: equity.sellPricePerUnit
                        };
                    });
                    return (new fromPortfolio.PortfolioLoaded({portfolio: portfolio}));
                }),
                catchError(error => {
                    return of(new fromPortfolio.PortfolioError({error}));
                })
            )
        ),
    );

    @Effect()
    symbols_query$ = this.actions$.pipe(
        ofType(PortfolioActionTypes.SYMBOL_LIST_QUERY),
        switchMap(() => this.portfolioService.getAllSymbols()
            .pipe(
                map((data: any) => {
                    const symbolList: EquitySymbol[] = data.map((res: any) => {
                        const key = res.payload.key;
                        const symbol: EquitySymbol = res.payload.val();
                        return {
                            key: key,
                            value: symbol
                        };
                    });
                    return (new fromPortfolio.SymbolListLoaded({symbolList: symbolList}));
                }),
                catchError(error => {
                    return of(new fromPortfolio.PortfolioError({error}));
                })
            )
        ),
    );


    @Effect({dispatch: false})
    sell = this.actions$.pipe(
        ofType(PortfolioActionTypes.EQUITY_SOLD),
        map((action: fromPortfolio.EquitySold) => action.payload),
        withLatestFrom(this.store.pipe(select(getUser))),
        switchMap(([payload, user]: any) => this.portfolioService.sell(payload.equity, user.uid)
            .pipe(
                catchError(error => {
                    return of(new fromPortfolio.EquityTransError({error}));
                }))
        )
    );

    @Effect({dispatch: false})
    purchased = this.actions$.pipe(
        ofType(PortfolioActionTypes.EQUITY_PURCHASED),
        map((action: fromPortfolio.EquityPurchased) => action.payload),
        withLatestFrom(this.store.pipe(select(getUser))),
        switchMap(([payload, user]: any) => this.portfolioService.add(payload.equity, user.uid))
    );

}
