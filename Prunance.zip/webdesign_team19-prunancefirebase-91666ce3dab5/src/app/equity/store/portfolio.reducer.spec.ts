import { portfolioReducer} from './portfolio.reducer';
import { portfolioInitialState } from './portfolio.state';

describe('Portfolio Reducer', () => {
  describe('an unknown action', () => {
    it('should return the previous state', () => {
      const action = {} as any;

      const result = portfolioReducer(portfolioInitialState, action);

      expect(result).toBe(portfolioInitialState);
    });
  });
});
