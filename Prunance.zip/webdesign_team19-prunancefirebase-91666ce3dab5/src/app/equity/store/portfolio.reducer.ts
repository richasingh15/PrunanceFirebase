import {portfolioInitialState, PortfolioState} from './portfolio.state';
import {PortfolioActions, PortfolioActionTypes} from './portfolio.actions';

export function portfolioReducer(state = portfolioInitialState, action: PortfolioActions): PortfolioState {
    switch (action.type) {

        case PortfolioActionTypes.PORTFOLIO_QUERY: {
            return Object.assign({}, state, {
                isLoading: true,
            });
        }

        case PortfolioActionTypes.PORTFOLIO_LOADED: {
            return Object.assign({}, state, {
                portfolio: action.payload.portfolio,
                isLoading: false,
            });
        }

        case PortfolioActionTypes.PORTFOLIO_ERROR: {
            return Object.assign({}, state, {
                isLoading: false,
                error: action.payload.error
            });
        }

        default:
            return state;
    }
}
