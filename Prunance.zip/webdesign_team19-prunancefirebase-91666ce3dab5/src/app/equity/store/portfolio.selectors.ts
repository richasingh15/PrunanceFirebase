import {createSelector, createFeatureSelector} from '@ngrx/store';
import {PortfolioState, SymbolListState} from './portfolio.state';

export const getPortfolioState = createFeatureSelector<PortfolioState>('portfolio');
export const getSymbolListState = createFeatureSelector<SymbolListState>('symbolList');

export const getPortfolio = createSelector(
    getPortfolioState,
    portfolio => portfolio.portfolio
);

export const getSymbolList = createSelector(
    getSymbolListState,
    symbolList => symbolList.symbolList
);

export const getIsLoading = createSelector(
    getPortfolioState,
    portfolio => portfolio.isLoading
);

export const getError = createSelector(
    getPortfolioState,
    portfolio => portfolio.error
);
