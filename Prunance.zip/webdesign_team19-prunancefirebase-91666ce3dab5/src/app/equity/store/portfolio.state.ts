import { Equity } from '../models/equity.model';
import { EquitySymbol } from '../models/equity-symbol.model';

export interface PortfolioState {
    portfolio: Equity[] | null;
    isLoading: boolean;
    error: any;
}

export const portfolioInitialState: PortfolioState = {
    portfolio: null,
    isLoading: true,
    error: null
};

export interface SymbolListState {
    symbolList: EquitySymbol[] | null;
    isLoading: boolean;
    error: any;
}

export const symbolListInitialState: SymbolListState = {
    symbolList: null,
    isLoading: true,
    error: null
}


