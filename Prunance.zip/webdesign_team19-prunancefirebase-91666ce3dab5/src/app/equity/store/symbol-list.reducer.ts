import {symbolListInitialState, SymbolListState} from './portfolio.state';
import {PortfolioActions, PortfolioActionTypes} from './portfolio.actions';

export function symbolListReducer(state = symbolListInitialState, action: PortfolioActions): SymbolListState {
    switch (action.type) {

        case PortfolioActionTypes.SYMBOL_LIST_QUERY: {
            return Object.assign({}, state, {
                isLoading: true,
            });
        }

        case PortfolioActionTypes.SYMBOL_LIST_LOADED: {
            return Object.assign({}, state, {
                portfolio: action.payload.symbolList,
                isLoading: false,
            });
        }

        case PortfolioActionTypes.SYMBOL_LIST_ERROR: {
            return Object.assign({}, state, {
                isLoading: false,
                error: action.payload.error
            });
        }

        default:
            return state;
    }
}
