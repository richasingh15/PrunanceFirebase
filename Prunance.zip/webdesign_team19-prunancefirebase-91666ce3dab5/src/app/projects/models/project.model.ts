export interface Project {
  key?: any;
  title?: string;
  description?: string;
  photoUrl?: string;
}
