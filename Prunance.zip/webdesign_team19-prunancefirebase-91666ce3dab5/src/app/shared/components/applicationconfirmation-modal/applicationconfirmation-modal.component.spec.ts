import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplicationconfirmationModalComponent } from './applicationconfirmation-modal.component';

describe('ApplicationconfirmationModalComponent', () => {
  let component: ApplicationconfirmationModalComponent;
  let fixture: ComponentFixture<ApplicationconfirmationModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApplicationconfirmationModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplicationconfirmationModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
