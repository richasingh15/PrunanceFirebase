import { Component, OnInit } from '@angular/core';
import {MDBModalRef} from 'angular-bootstrap-md';

@Component({
  selector: 'app-applicationconfirmation-modal',
  templateUrl: './applicationconfirmation-modal.component.html',
  styleUrls: ['./applicationconfirmation-modal.component.scss']
})
export class ApplicationconfirmationModalComponent implements OnInit {

  constructor(public modalRef: MDBModalRef) { }

  ngOnInit() {
  }

}
