import {Component, OnInit, Output, EventEmitter, Input} from '@angular/core';
import {Career} from '../../../core/careers/models/career.model';
@Component({
    selector: 'app-career-list',
    templateUrl: './career-list.component.html',
    styleUrls: ['./career-list.component.scss']
})
export class CareerListComponent implements OnInit {
    @Input() careers: Career[];

    @Output() careerApplicationRequested = new EventEmitter<Career>();

    constructor() {
    }

    ngOnInit() {
    }

    /*onApplyCareer() {
        this.modalRef = this.modalService.show(CareersModalComponent, this.modalConfig);

        this.modalRef.content.heading = 'Add new customer';
        // this.modalRef.content.customer.id = this.lastCustomerIndex + 1;

        this.modalRef.content.customerData.pipe(take(1)).subscribe((careerData: Career) => {
            this.store.dispatch(new fromCareers.CareersAdded({career: careerData}));
        });
    }*/

    onApplyCareer(career: Career) {
        this.careerApplicationRequested.emit(career);
    }

}
