import {Component, EventEmitter, OnInit, Output, ViewChild} from '@angular/core';
import {MDBModalRef, MDBModalService} from 'angular-bootstrap-md';
import {Careerapplication} from '../../../core/careers/models/careerapplication.model';
import {Subject} from 'rxjs';
import {NgForm} from '@angular/forms';
import {CareersService} from '../../../core/careers/services/careers.service';
import {AngularFireFunctions} from '@angular/fire/functions';
import {Career} from '../../../core/careers/models/career.model';
import {ApplicationconfirmationModalComponent} from '../applicationconfirmation-modal/applicationconfirmation-modal.component';

@Component({
    selector: 'app-careers-modal',
    templateUrl: './careers-modal.component.html',
    styleUrls: ['./careers-modal.component.scss']
})
export class CareersModalComponent implements OnInit {
    @ViewChild('careerForm', {static: true}) careerForm: NgForm;
    @Output() careerApplicationSubmitted = new EventEmitter<Careerapplication>();

    heading: string;
    careerPosition: Career = {};
    career: Careerapplication = {};

    modalConfig = {
        // backdrop: 'static',
        class: 'modal-dialog-centered',
    };

    careerData: Subject<Careerapplication> = new Subject();

    stateList = [
        {
            name: 'Alabama',
            abbreviation: 'AL'
        },
        {
            name: 'Alaska',
            abbreviation: 'AK'
        },
        {
            name: 'American Samoa',
            abbreviation: 'AS'
        },
        {
            name: 'Arizona',
            abbreviation: 'AZ'
        },
        {
            name: 'Arkansas',
            abbreviation: 'AR'
        },
        {
            name: 'California',
            abbreviation: 'CA'
        },
        {
            name: 'Colorado',
            abbreviation: 'CO'
        },
        {
            name: 'Connecticut',
            abbreviation: 'CT'
        },
        {
            name: 'Delaware',
            abbreviation: 'DE'
        },
        {
            name: 'District Of Columbia',
            abbreviation: 'DC'
        },
        {
            name: 'Federated States Of Micronesia',
            abbreviation: 'FM'
        },
        {
            name: 'Florida',
            abbreviation: 'FL'
        },
        {
            name: 'Georgia',
            abbreviation: 'GA'
        },
        {
            name: 'Guam',
            abbreviation: 'GU'
        },
        {
            name: 'Hawaii',
            abbreviation: 'HI'
        },
        {
            name: 'Idaho',
            abbreviation: 'ID'
        },
        {
            name: 'Illinois',
            abbreviation: 'IL'
        },
        {
            name: 'Indiana',
            abbreviation: 'IN'
        },
        {
            name: 'Iowa',
            abbreviation: 'IA'
        },
        {
            name: 'Kansas',
            abbreviation: 'KS'
        },
        {
            name: 'Kentucky',
            abbreviation: 'KY'
        },
        {
            name: 'Louisiana',
            abbreviation: 'LA'
        },
        {
            name: 'Maine',
            abbreviation: 'ME'
        },
        {
            name: 'Marshall Islands',
            abbreviation: 'MH'
        },
        {
            name: 'Maryland',
            abbreviation: 'MD'
        },
        {
            name: 'Massachusetts',
            abbreviation: 'MA'
        },
        {
            name: 'Michigan',
            abbreviation: 'MI'
        },
        {
            name: 'Minnesota',
            abbreviation: 'MN'
        },
        {
            name: 'Mississippi',
            abbreviation: 'MS'
        },
        {
            name: 'Missouri',
            abbreviation: 'MO'
        },
        {
            name: 'Montana',
            abbreviation: 'MT'
        },
        {
            name: 'Nebraska',
            abbreviation: 'NE'
        },
        {
            name: 'Nevada',
            abbreviation: 'NV'
        },
        {
            name: 'New Hampshire',
            abbreviation: 'NH'
        },
        {
            name: 'New Jersey',
            abbreviation: 'NJ'
        },
        {
            name: 'New Mexico',
            abbreviation: 'NM'
        },
        {
            name: 'New York',
            abbreviation: 'NY'
        },
        {
            name: 'North Carolina',
            abbreviation: 'NC'
        },
        {
            name: 'North Dakota',
            abbreviation: 'ND'
        },
        {
            name: 'Northern Mariana Islands',
            abbreviation: 'MP'
        },
        {
            name: 'Ohio',
            abbreviation: 'OH'
        },
        {
            name: 'Oklahoma',
            abbreviation: 'OK'
        },
        {
            name: 'Oregon',
            abbreviation: 'OR'
        },
        {
            name: 'Palau',
            abbreviation: 'PW'
        },
        {
            name: 'Pennsylvania',
            abbreviation: 'PA'
        },
        {
            name: 'Puerto Rico',
            abbreviation: 'PR'
        },
        {
            name: 'Rhode Island',
            abbreviation: 'RI'
        },
        {
            name: 'South Carolina',
            abbreviation: 'SC'
        },
        {
            name: 'South Dakota',
            abbreviation: 'SD'
        },
        {
            name: 'Tennessee',
            abbreviation: 'TN'
        },
        {
            name: 'Texas',
            abbreviation: 'TX'
        },
        {
            name: 'Utah',
            abbreviation: 'UT'
        },
        {
            name: 'Vermont',
            abbreviation: 'VT'
        },
        {
            name: 'Virgin Islands',
            abbreviation: 'VI'
        },
        {
            name: 'Virginia',
            abbreviation: 'VA'
        },
        {
            name: 'Washington',
            abbreviation: 'WA'
        },
        {
            name: 'West Virginia',
            abbreviation: 'WV'
        },
        {
            name: 'Wisconsin',
            abbreviation: 'WI'
        },
        {
            name: 'Wyoming',
            abbreviation: 'WY'
        }
    ];

    constructor(private modalService: MDBModalService, public service: CareersService,
                public modalRef: MDBModalRef, private fun: AngularFireFunctions) {
    }

    ngOnInit() {

    }

    onSave() {
        if (this.careerForm.valid) {
            /*const httpOptions = {
                headers: new HttpHeaders({
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer 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'
                })
            };
            this.http.post('https://api.sendgrid.com/v3/mail/send',
                JSON.stringify({
                    'personalizations': [{'to': [{'email': 'singh.ric@husky.neu.edu'}]}],
                    'from': {'email': 'noreply@prunance.com'},
                    'subject': 'Sending with SendGrid is Fun',
                    'content': [{'type': 'text/plain', 'value': 'and easy to do anywhere, even with cURL'}]
                }),
                httpOptions).subscribe();*/

            // console.log(this.career);
            this.service.saveApplication(this.career);
            this.careerData.next(this.career);
            this.modalRef.hide();
            // alert('Thankyou for your Application');
            const callable = this.fun.httpsCallable('sendMail');
            callable({role: this.careerPosition.name, name: this.career.applicantname, email: this.career.emailid}).subscribe();
            // this.careerApplicationSubmitted.emit(this.career);
            // alert('Thankyou for your Application');

            this.modalRef = this.modalService.show(ApplicationconfirmationModalComponent, this.modalConfig);

            this.modalRef.content.heading = 'Application Confirmation';
            this.modalRef.content.careerapplication = this.career;
        } else {
            const controls = this.careerForm.controls;
            Object.keys(controls).forEach(controlName => controls[controlName].markAsTouched());
        }
    }

}
