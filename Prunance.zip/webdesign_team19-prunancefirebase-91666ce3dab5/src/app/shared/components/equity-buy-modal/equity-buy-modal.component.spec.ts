import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EquityBuyModalComponent } from './equity-buy-modal.component';

describe('EquityBuyModalComponent', () => {
  let component: EquityBuyModalComponent;
  let fixture: ComponentFixture<EquityBuyModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EquityBuyModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EquityBuyModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
