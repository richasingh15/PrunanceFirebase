import {Component, OnInit, ViewChild} from '@angular/core';
import {MDBModalRef} from 'angular-bootstrap-md';
import {Equity} from '../../../equity/models/equity.model';
import {EquitySymbol} from '../../../equity/models/equity-symbol.model';
import {Observable, of, Subject} from 'rxjs';
import {NgForm} from '@angular/forms';
import {PortfolioService} from '../../../equity/services/portfolio.service';
import {catchError, debounceTime, distinctUntilChanged, switchMap, tap} from 'rxjs/operators';
import {NgbTypeaheadSelectItemEvent} from '@ng-bootstrap/ng-bootstrap';
import {HttpClient} from '@angular/common/http';
import {ICreateOrderRequest, IPayPalConfig} from 'ngx-paypal';
import {AppSettings} from '../../../app-settings';

@Component({
    selector: 'app-equity-buy-modal',
    templateUrl: './equity-buy-modal.component.html',
    styleUrls: ['./equity-buy-modal.component.scss']
})
export class EquityBuyModalComponent implements OnInit {
    @ViewChild('buyEquityForm', {static: true}) buyEquityForm: NgForm;

    isLoading$: Observable<boolean>;

    symbolList: EquitySymbol[] | null;

    heading: string;
    equity: Equity = {};

    equityData: Subject<Equity> = new Subject();

    searching = false;
    searchFailed = false;

    selectedEquitySymbol: EquitySymbol;
    httpObj: any;

    currentPrice: string;
    totalPrice: string;

    lockedPricePerUnit: number;

    orderConfirmed = false;

    public payPalConfig ?: IPayPalConfig;

    constructor(private _service: PortfolioService, public modalRef: MDBModalRef, httpClient: HttpClient) {
        this.httpObj = httpClient;
    }

    formatMatches = (value: EquitySymbol) => (value.name + ' -- ' + value.symbol) || '';
    search = (text$: Observable<string>) =>
        text$.pipe(
            debounceTime(300),
            distinctUntilChanged(),
            tap(() => this.searching = true),
            switchMap(term =>
                this._service.getSymbolByNameLike(term).pipe(
                    tap(() => this.searchFailed = false),
                    catchError(() => {
                        this.searchFailed = true;
                        return of([]);
                    }))
            ),
            tap(() => this.searching = false)
        );

    private initPaypalConfig(pricePerUnit: number, volume: number, equityName?: string): void {

        this.payPalConfig = {
            currency: 'USD',
            clientId: 'AVasrClpvWPXwRhUEGF7C1_fFnPSxLyQ6qDlVV2F4VtjDKTlicrlmJcTJbdjfXAxaoMepefBc2xuzBxL',
            createOrderOnClient: () => <ICreateOrderRequest>{
                intent: 'CAPTURE',
                purchase_units: [{
                    amount: {
                        currency_code: 'USD',
                        value: (pricePerUnit * volume).toFixed(2).toString(),
                        breakdown: {
                            item_total: {
                                currency_code: 'USD',
                                value: (pricePerUnit * volume).toFixed(2).toString()
                            }
                        }
                    },
                    items: [{
                        name: equityName + ' Equity',
                        quantity: volume.toString(),
                        category: 'DIGITAL_GOODS',
                        unit_amount: {
                            currency_code: 'USD',
                            value: pricePerUnit.toString(),
                        },
                    }]
                }]
            },
            advanced: {
                commit: 'true'
            },
            style: {
                label: 'paypal',
                layout: 'vertical'
            },
            onApprove: (data, actions) => {
                console.log('onApprove - transaction was approved, but not authorized', data, actions);
                actions.order.get().then((details: any) => {
                    console.log('onApprove - you can get full order details inside onApprove: ', details);
                });

            },
            onClientAuthorization: (data) => {
                console.log('onClientAuthorization - you should probably inform your server ' +
                    'about completed transaction at this point', data);
                this.equity.status = 'PURCHASED';
                this.equity.purchaseDate = new Date();

                this.equityData.next(this.equity);
                this.modalRef.hide();
                // this.showSuccess = true;
            },
            onCancel: (data, actions) => {
                console.log('OnCancel', data, actions);
                // this.showCancel = true;
                alert('Transaction Cancelled');

            },
            onError: err => {
                console.log('OnError', err);
                // this.showError = true;
                alert('Transaction Error');
            },
            onClick: (data, actions) => {
                console.log('onClick', data, actions);
                // this.resetStatus();
            }
        };
    };


    ngOnInit() {
        this.currentPrice = '';
        this.totalPrice = '';
        /*this._service.getSymbolByNameLike(this.startAt, this.endAt)
            .subscribe(symbols => {
                this.symbolList = symbols;
                console.log(symbols);
            });*/

    }

    onSymbolSelected(item: NgbTypeaheadSelectItemEvent) {
        this.selectedEquitySymbol = item.item;
        this.httpObj.get('https://api.worldtradingdata.com/api/v1/stock?symbol=' +
            this.selectedEquitySymbol.symbol +
            '&api_token=' + AppSettings.WORLD_DATA_TOKEN)
            .subscribe((resp: any) => {
                this.currentPrice = resp.data[0]['price'];
                if (typeof this.currentPrice === 'undefined') {
                    this.currentPrice = '';
                } else if (this.equity.volume) {
                    this.totalPrice = (this.equity.volume * parseFloat(this.currentPrice)).toString();
                }
            });
    }

    onConfirm() {

        if (this.buyEquityForm.valid) {
            if (this.equity.volume === undefined) {
                return;
            }
            if (this.selectedEquitySymbol === undefined) {
                alert('Please select a symbol');
                return;
            }
            this.lockedPricePerUnit = parseFloat(this.currentPrice);
            this.equity.symbol = this.selectedEquitySymbol.symbol;
            this.equity.longName = this.selectedEquitySymbol.name;
            this.equity.pricePerUnit = this.lockedPricePerUnit;
            // console.log(this.equity);
            /*this.equityData.next(this.equity);
            this.modalRef.hide();*/
            this.orderConfirmed = true;
            // console.log(this.lockedPricePerUnit);
            // console.log(this.equity.volume);
            this.initPaypalConfig(this.lockedPricePerUnit, this.equity.volume, this.selectedEquitySymbol.name);
        } else {
            const controls = this.buyEquityForm.controls;
            Object.keys(controls).forEach(controlName => controls[controlName].markAsTouched());
        }
    }

    onQuantityKeyUp($event: any) {
        if (this.selectedEquitySymbol && this.currentPrice) {
            this.totalPrice = ($event.target.value * parseFloat(this.currentPrice)).toFixed(2).toString();
        }
    }
}
