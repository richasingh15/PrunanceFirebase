import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {Equity} from '../../../equity/models/equity.model';

@Component({
    selector: 'app-equity-list',
    templateUrl: './equity-list.component.html',
    styleUrls: ['./equity-list.component.scss']
})
export class EquityListComponent implements OnInit {
    @Input() portfolio: Equity[];
    @Output() equitySold = new EventEmitter<Equity>();

    constructor() {
    }

    ngOnInit() {
    }

    trackByFn(index: any) {
        return index;
    }

    onSell(equity: Equity) {
        // if (confirm('Are you sure you want to sell the equity')) {
        this.equitySold.emit(equity);
        // }
    }
}
