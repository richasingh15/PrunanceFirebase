import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EquitySellModalComponent } from './equity-sell-modal.component';

describe('EquitySellModalComponent', () => {
  let component: EquitySellModalComponent;
  let fixture: ComponentFixture<EquitySellModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EquitySellModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EquitySellModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
