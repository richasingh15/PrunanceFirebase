import {Component, OnInit, ViewChild} from '@angular/core';
import {NgForm} from '@angular/forms';
import {MDBModalRef} from 'angular-bootstrap-md';
import {Equity} from '../../../equity/models/equity.model';
import {Subject} from 'rxjs';

@Component({
    selector: 'app-equity-sell-modal',
    templateUrl: './equity-sell-modal.component.html',
    styleUrls: ['./equity-sell-modal.component.scss']
})
export class EquitySellModalComponent implements OnInit {
    @ViewChild('sellEquityForm', {static: true}) sellEquityForm: NgForm;

    heading: string;
    equity: Equity = {};
    currentPrice: string;
    totalPrice: string;

    equityData: Subject<Equity> = new Subject();


    constructor(public modalRef: MDBModalRef) {
    }


    ngOnInit() {
        /*this.httpClient.get('https://api.worldtradingdata.com/api/v1/stock?symbol=' +
            this.equity.symbol +
            '&api_token=lB5FP2bUhbq7UK6kLrkbxySFTO3eGJpgu78aQboxAscJrRXuEmdis8OUWVuY')
            .subscribe((resp: any) => {
                this.currentPrice = resp.data[0]['price'];
                if (typeof this.currentPrice === 'undefined') {
                    this.currentPrice = '';
                } else if (this.equity.volume) {
                    this.totalPrice = (this.equity.volume * parseFloat(this.currentPrice)).toString();
                }
            });*/
    }


    onSell() {
        if (this.currentPrice === undefined || isNaN(parseFloat(this.currentPrice))) {
            alert('Could not get current price data');
            return;
        }
        if (confirm('Are you sure you want to sell?')) {
            this.equity.sellPricePerUnit = parseFloat(this.currentPrice);
            this.equity.sellDate = new Date();
            this.equity.status = 'SOLD';
            this.equityData.next(this.equity);
            this.modalRef.hide();
        }
    }

}
