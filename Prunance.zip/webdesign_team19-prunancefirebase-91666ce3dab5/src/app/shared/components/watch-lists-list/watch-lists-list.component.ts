import {Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import {WatchList} from '../../../watch-list/models/watch-list.model';
import {HttpClient} from '@angular/common/http';
import {interval} from 'rxjs';
import {AppSettings} from '../../../app-settings';

@Component({
    selector: 'app-watch-lists-list',
    templateUrl: './watch-lists-list.component.html',
    styleUrls: ['./watch-lists-list.component.scss']
})
export class WatchListsListComponent implements OnInit {
    @Input() watchLists: WatchList[];
    @Output() watchListDeleted = new EventEmitter<WatchList>();
    @Output() watchListEdited = new EventEmitter<WatchList>();

    httpObj: any;
    watchListsWithApi: any;

    constructor(http: HttpClient) {
        this.httpObj = http;
        this.watchListsWithApi = [];
    }

    updateSomething() {
        for (const watchList of this.watchLists) {
            this.httpObj.get('https://api.worldtradingdata.com/api/v1/stock?symbol=' +
                watchList.symbol +
                '&api_token=' + AppSettings.WORLD_DATA_TOKEN)
                .subscribe((resp: any) => {
                    console.log(resp);
                    const arrObj: any = {};
                    arrObj['symbol'] = resp.data[0]['symbol'];
                    arrObj['description'] = watchList.description;
                    arrObj['day_change'] = resp.data[0]['day_change'];
                    arrObj['change_pct'] = resp.data[0]['change_pct'];
                    arrObj['price'] = resp.data[0]['price'];
                    arrObj['name'] = resp.data[0]['name'];
                    arrObj['currency'] = resp.data[0]['currency'];
                    arrObj['wl'] = watchList;
                    watchList.name = resp.data[0]['name'];
                    watchList.change_pct = resp.data[0]['day_change'];
                    watchList.day_change = resp.data[0]['change_pct'];
                    watchList.currency = resp.data[0]['currency'];
                    watchList.price = resp.data[0]['price'];
                    this.watchListsWithApi.push(arrObj);
                });
        }
    }

    ngOnInit() {
        this.updateSomething();
        interval(3000000).subscribe(() => {
            this.updateSomething();
        });

    }

    onEdit(watchList: WatchList) {
        this.watchListEdited.emit(watchList);
    }

    onDelete(watchList: WatchList) {
        this.watchListDeleted.emit(watchList);
    }

    trackByFn(index: any) {
        return index;
    }
}
