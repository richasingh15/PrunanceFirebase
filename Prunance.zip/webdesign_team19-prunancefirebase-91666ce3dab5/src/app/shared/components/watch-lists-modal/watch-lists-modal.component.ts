import {Component, OnInit, ViewChild} from '@angular/core';
import {MDBModalRef} from 'angular-bootstrap-md';
import {WatchList} from '../../../watch-list/models/watch-list.model';
import {Observable, of, Subject} from 'rxjs';
import {NgForm} from '@angular/forms';
import {PortfolioService} from '../../../equity/services/portfolio.service';
import {EquitySymbol} from '../../../equity/models/equity-symbol.model';
import {catchError, debounceTime, distinctUntilChanged, switchMap, tap} from 'rxjs/operators';
import {NgbTypeaheadSelectItemEvent} from '@ng-bootstrap/ng-bootstrap';

// import {ElementRef} from '@angular/core';

@Component({
    selector: 'app-watch-lists-modal',
    templateUrl: './watch-lists-modal.component.html',
    styleUrls: ['./watch-lists-modal.component.scss']
})
export class WatchListsModalComponent implements OnInit {
    @ViewChild('customerForm', {static: true}) watchListForm: NgForm;
    heading: string;
    watchList: WatchList = {};
    isEdit: boolean;
    searching = false;
    searchFailed = false;
    selectedEquitySymbol: EquitySymbol;

    watchListData: Subject<WatchList> = new Subject();

    constructor(private _service: PortfolioService, public modalRef: MDBModalRef) {
    }

    formatMatches = (value: EquitySymbol) => (value.name + ' -- ' + value.symbol) || '';
    search = (text$: Observable<string>) =>
        text$.pipe(
            debounceTime(300),
            distinctUntilChanged(),
            tap(() => this.searching = true),
            switchMap(term =>
                this._service.getSymbolByNameLike(term).pipe(
                    tap(() => this.searchFailed = false),
                    catchError(() => {
                        this.searchFailed = true;
                        return of([]);
                    }))
            ),
            tap(() => this.searching = false)
        );
    ngOnInit() {
    }

    onSymbolSelected(item: NgbTypeaheadSelectItemEvent) {
        this.selectedEquitySymbol = item.item;
    }

    onSave() {
        if (!this.selectedEquitySymbol && !this.isEdit) {
            alert('Symbol does not exist!');
            return;
        }

        if (this.selectedEquitySymbol) {
            this.watchList.symbol = this.selectedEquitySymbol.symbol;
        }
        if (this.watchListForm.valid) {
            if (this.selectedEquitySymbol) {
                this.watchList.symbol = this.selectedEquitySymbol.symbol;
            }
            this.watchListData.next(this.watchList);
            this.modalRef.hide();
        } else {
            const controls = this.watchListForm.controls;
            Object.keys(controls).forEach(controlName => controls[controlName].markAsTouched());
        }
    }

}
