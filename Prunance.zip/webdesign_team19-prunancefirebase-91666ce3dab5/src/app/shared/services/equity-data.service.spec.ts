import { TestBed } from '@angular/core/testing';

import { EquityDataService } from './equity-data.service';

describe('EquityDataService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: EquityDataService = TestBed.get(EquityDataService);
    expect(service).toBeTruthy();
  });
});
