import {Injectable} from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class EquityDataService {

    constructor() {
    }

    /*getRealtimeData() {
        this.httpObj.get('https://api.worldtradingdata.com/api/v1/stock?symbol=' +
            this.indexKeys.nasdaq +
            '&api_token=WqWMht4hWURP5c4uOwj5tfI4lROPxg6sFEweo1MCHOxIcv7a4D2mYD6eNu2z')
            .subscribe((resp: any) => {
                this.sensexValues.nasdaq = resp.data[0];
            });
    }*/
}
