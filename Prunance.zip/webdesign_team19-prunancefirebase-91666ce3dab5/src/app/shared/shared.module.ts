import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {ConfirmModalComponent} from './components/confirm-modal/confirm-modal.component';
import {
    ButtonsModule,
    InputsModule,
    CardsModule,
    InputUtilitiesModule,
    IconsModule,
    TableModule,
    WavesModule
} from 'angular-bootstrap-md';
import {CustomersModalComponent} from './components/customers-modal/customers-modal.component';
import {ProjectModalComponent} from './components/project-modal/project-modal.component';
import {FormsModule} from '@angular/forms';
import {ProjectComponent} from './components/project/project.component';
import {ProjectsListComponent} from './components/projects-list/projects-list.component';
import {CustomersListComponent} from './components/customers-list/customers-list.component';
import {EquityListComponent} from './components/equity-list/equity-list.component';
import {EquityBuyModalComponent} from './components/equity-buy-modal/equity-buy-modal.component';
import {WatchListsModalComponent} from './components/watch-lists-modal/watch-lists-modal.component';
import {WatchListsListComponent} from './components/watch-lists-list/watch-lists-list.component';
import {NgbTypeaheadModule} from '@ng-bootstrap/ng-bootstrap';
import {NgxPayPalModule} from 'ngx-paypal';
import {CareerListComponent} from './components/career-list/career-list.component';
import {CareersModalComponent} from './components/careers-modal/careers-modal.component';
import {ApplicationconfirmationModalComponent} from './components/applicationconfirmation-modal/applicationconfirmation-modal.component';
import {EquitySellModalComponent} from './components/equity-sell-modal/equity-sell-modal.component';

@NgModule({
    declarations: [
        ConfirmModalComponent,
        CustomersModalComponent,
        ProjectModalComponent,
        ProjectsListComponent,
        ProjectComponent,
        CustomersListComponent,
        EquityListComponent,
        EquityBuyModalComponent,
        WatchListsModalComponent,
        WatchListsListComponent,
        CareerListComponent,
        CareersModalComponent,
        ApplicationconfirmationModalComponent,
        EquitySellModalComponent
    ],
    imports: [
        CommonModule,
        InputsModule,
        InputUtilitiesModule,
        IconsModule,
        FormsModule,
        ButtonsModule,
        CardsModule,
        TableModule,
        WavesModule,
        NgbTypeaheadModule,
        NgxPayPalModule
    ],
    exports: [ProjectsListComponent, ProjectComponent, CustomersListComponent, CareerListComponent,
        EquityListComponent, WatchListsListComponent, CareersModalComponent],
    providers: [],
    entryComponents: [
        ConfirmModalComponent,
        CustomersModalComponent,
        EquityBuyModalComponent,
        EquitySellModalComponent,
        ProjectModalComponent,
        WatchListsModalComponent,
        WatchListsListComponent,
        CareersModalComponent,
        ApplicationconfirmationModalComponent
    ]
})
export class SharedModule {
}
