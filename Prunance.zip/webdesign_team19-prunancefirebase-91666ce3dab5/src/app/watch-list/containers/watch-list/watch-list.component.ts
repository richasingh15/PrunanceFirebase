import {Component, OnInit, OnDestroy} from '@angular/core';
import {MDBModalRef, MDBModalService} from 'angular-bootstrap-md';
import {Store} from '@ngrx/store';
import {AppState} from '../../../reducers';

import * as fromWatchLists from './../../store/watch-list.actions';
import {WatchList} from '../../models/watch-list.model';
import {Subscription, Observable} from 'rxjs';
import {getWatchLists, getIsLoading} from '../../store/watch-list.selectors';
import {take, map} from 'rxjs/operators';
import {ConfirmModalComponent} from '../../../shared/components/confirm-modal/confirm-modal.component';
import {WatchListsModalComponent} from '../../../shared/components/watch-lists-modal/watch-lists-modal.component';
import {AngularFireAuth} from '@angular/fire/auth';

@Component({
    selector: 'app-watch-list',
    templateUrl: './watch-list.component.html',
    styleUrls: ['./watch-list.component.css']
})

export class WatchListComponent implements OnInit, OnDestroy {
    isLoading$: Observable<boolean>;
    watchLists: WatchList[] | null;
    modalRef: MDBModalRef;
    flag: boolean;

    watchListsSub: Subscription;

    modalConfig = {
        class: 'modal-dialog-centered'
    };

    lastWatchListIndex: number;

    constructor(private modalService: MDBModalService, private store: Store<AppState>, private afAuth: AngularFireAuth) {
        this.flag = false;
    }

    ngOnInit() {
        this.isLoading$ = this.store.select(getIsLoading);

        this.watchListsSub = this.store.select(getWatchLists).pipe(
            map((watchLists: WatchList[]) => {
                if (this.user && !watchLists) {
                    this.store.dispatch(new fromWatchLists.WatchListsQuery());
                }
                return watchLists;
            })
        )
            .subscribe((watchLists: WatchList[]) => {
                if (watchLists) {
                    if (watchLists.length > 0) {
                        this.flag = true;
                    }
                }

                this.watchLists = watchLists;
            });

    }

    get user() {
        return this.afAuth.auth.currentUser;
    }

    ngOnDestroy() {
        if (this.watchListsSub) {
            this.watchListsSub.unsubscribe();
        }
    }

    onAddWatchList() {
        this.modalRef = this.modalService.show(WatchListsModalComponent, this.modalConfig);

        this.modalRef.content.heading = 'Add new watch list (watch list item)';
        this.modalRef.content.isEdit = false;
        this.modalRef.content.watchListData.pipe(take(1)).subscribe((watchListData: WatchList) => {
            this.store.dispatch(new fromWatchLists.WatchListsAdded({watchList: watchListData}));
        });
    }

    openEditWatchListModal(watchList: WatchList) {
        this.modalRef = this.modalService.show(WatchListsModalComponent, this.modalConfig);

        this.modalRef.content.heading = 'Edit watch list (watch list item)';
        this.modalRef.content.isEdit = true;
        const watchListCopy = {
            key: watchList.key,
            // id: watchList.id || null,
            name: watchList.name || null,
            description: watchList.description || null,
            symbol: watchList.symbol || null
        };
        this.modalRef.content.watchList = watchListCopy;

        this.modalRef.content.watchListData.pipe(take(1)).subscribe((watchListData: WatchList) => {
            this.store.dispatch(new fromWatchLists.WatchListsEdited({watchList: watchListData}));
        });
    }

    openConfirmModal(watchList: WatchList) {
        this.modalRef = this.modalService.show(ConfirmModalComponent, this.modalConfig);

        this.modalRef.content.confirmation.pipe(take(1)).subscribe((confirmation: boolean) => {
            if (confirmation) {
                this.store.dispatch(new fromWatchLists.WatchListsDeleted({watchList}));
            }
        });
    }

    onWatchListEdit(watchList: WatchList) {
        this.openEditWatchListModal(watchList);
    }

    onWatchListDelete(watchList: WatchList) {
        this.openConfirmModal(watchList);
    }

}
