export interface WatchList {
    key?: any;
    id?: number;
    name?: string;
    description?: string;
    symbol?: string;
    price?: string;
    currency?: string;
    change_pct?: string;
    day_change?: string;
}
