import {Injectable} from '@angular/core';
import {AngularFireDatabase} from '@angular/fire/database';
import {WatchList} from '../models/watch-list.model';
import {of} from 'rxjs';
import {AngularFireAuth} from '@angular/fire/auth';

@Injectable({
    providedIn: 'root'
})
export class WatchListService {

    constructor(private db: AngularFireDatabase, private afAuth: AngularFireAuth) {
    }

    get userId() {
        if (this.afAuth.auth.currentUser) {
            return this.afAuth.auth.currentUser.uid;
        }
    }

    add(watchList: WatchList, userId: string) {
        const watchLists = this.db.list(`watch-lists/${userId}`);
        return watchLists.push(watchList);
    }

    addWatchLists(watchLists: WatchList[]) {
        const userId = this.userId;

        if (userId) {
            watchLists.forEach((watchList: WatchList) => {
                this.db.list(`watch-lists/${userId}`).push(watchList);
            });
        }
    }

    get(userId: string) {
        return this.db.list(`watch-lists/${userId}`)
            .snapshotChanges();
            /*.pipe(
                map((data: any) => {
                    console.log(data);
                    // const symbolList: EquitySymbol[] = data.map((res: any) => {
                    const symbolList: WatchList[] = data.map((res: any) => {
                        const key = res.payload.key;
                        const symbol: WatchList = res.payload.val();
                        return {
                            key: key,
                            symbol: symbol.symbol,
                            name: symbol.name,
                            description: symbol.description,
                            currency: '',
                            price: ''
                        };
                    });
                    return symbolList;
                })
            );*/
    }

    update(watchList: WatchList, userId: string) {
        return of(this.db.object(`watch-lists/${userId}/` + watchList.key)
            .update({
                // id: watchList.id,
                name: watchList.name,
                description: watchList.description,
                symbol: watchList.symbol,
            }));
    }

    delete(watchList: WatchList, userId: string) {
        return this.db.object(`watch-lists/${userId}/` + watchList.key).remove();
    }
}
