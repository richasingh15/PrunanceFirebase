import { Action } from '@ngrx/store';
import { WatchList } from '../models/watch-list.model';

export enum WatchListsActionTypes {
  WATCHLISTS_QUERY = '[WatchLists] Query',
  WATCHLISTS_LOADED = '[WatchLists] Fetched',

  WATCHLISTS_ADDED = '[WatchLists] Added',
  WATCHLISTS_EDITED = '[WatchLists] Edited',
  WATCHLISTS_DELETED = '[WatchLists] Deleted',

  WATCHLISTS_ERROR = '[WatchLists] Error'
}

export class WatchListsQuery implements Action {
  readonly type = WatchListsActionTypes.WATCHLISTS_QUERY;
}

export class WatchListsLoaded implements Action {
  readonly type = WatchListsActionTypes.WATCHLISTS_LOADED;

  constructor(public payload: { watchLists: WatchList[] }) {}
}

export class WatchListsAdded implements Action {
  readonly type = WatchListsActionTypes.WATCHLISTS_ADDED;

  constructor(public payload: { watchList: WatchList }) {}
}

export class WatchListsEdited implements Action {
  readonly type = WatchListsActionTypes.WATCHLISTS_EDITED;

  constructor(public payload: { watchList: WatchList }) {}
}

export class WatchListsDeleted implements Action {
  readonly type = WatchListsActionTypes.WATCHLISTS_DELETED;

  constructor(public payload: { watchList: WatchList }) {}
}

export class WatchListsError implements Action {
  readonly type = WatchListsActionTypes.WATCHLISTS_ERROR;

  constructor(public payload: { error: any }) {}
}

export type WatchListsActions =
  | WatchListsQuery
  | WatchListsLoaded
  | WatchListsAdded
  | WatchListsEdited
  | WatchListsDeleted
  | WatchListsError;
