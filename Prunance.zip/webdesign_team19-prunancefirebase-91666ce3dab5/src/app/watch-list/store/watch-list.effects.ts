import {Injectable} from '@angular/core';
import {Actions, Effect, ofType} from '@ngrx/effects';
import {WatchListService} from '../services/watch-list.service';
import {WatchListsActionTypes} from './watch-list.actions';
import {switchMap, map, catchError, withLatestFrom} from 'rxjs/operators';
import {WatchList} from '../models/watch-list.model';

import * as fromWatchLists from './../store/watch-list.actions';
import { of} from 'rxjs';
import {Store, select} from '@ngrx/store';
import {AppState} from '../../reducers';
import {getUser} from '../../auth/store/auth.selectors';

@Injectable()
export class WatchListEffects {

    constructor(private actions$: Actions, private watchListsService: WatchListService, private store: Store<AppState>) {
    }

    @Effect()
    query$ = this.actions$.pipe(
        ofType(WatchListsActionTypes.WATCHLISTS_QUERY),
        withLatestFrom(this.store.pipe(select(getUser))),
        switchMap(([, user]: any) => this.watchListsService.get(user.uid)
            .pipe(
                map((data: any) => {
                    const watchListsData: WatchList[] = data.map((res: any) => {
                        const key = res.payload.key;
                        const watchList: WatchList = res.payload.val();
                        return {
                            key: key,
                            name: watchList.name,
                            description: watchList.description,
                            symbol: watchList.symbol,
                        };
                    });
                    return (new fromWatchLists.WatchListsLoaded({watchLists: watchListsData}));
                }),
                catchError(error => {
                    return of(new fromWatchLists.WatchListsError({error}));
                })
            )
        ),
    );

    @Effect({dispatch: false})
    added$ = this.actions$.pipe(
        ofType(WatchListsActionTypes.WATCHLISTS_ADDED),
        map((action: fromWatchLists.WatchListsAdded) => action.payload),
        withLatestFrom(this.store.pipe(select(getUser))),
        switchMap(([payload, user]: any) => this.watchListsService.add(payload.watchList, user.uid))
    );

    @Effect({dispatch: false})
    edit$ = this.actions$.pipe(
        ofType(WatchListsActionTypes.WATCHLISTS_EDITED),
        map((action: fromWatchLists.WatchListsEdited) => action.payload),
        withLatestFrom(this.store.pipe(select(getUser))),
        switchMap(([payload, user]: any) => this.watchListsService.update(payload.watchList, user.uid)
            .pipe(
                catchError(error => {
                    return of(new fromWatchLists.WatchListsError({error}));
                }))
        )
    );

    @Effect({dispatch: false})
    delete$ = this.actions$.pipe(
        ofType(WatchListsActionTypes.WATCHLISTS_DELETED),
        map((action: fromWatchLists.WatchListsDeleted) => action.payload),
        withLatestFrom(this.store.pipe(select(getUser))),
        switchMap(([payload, user]: any) => this.watchListsService.delete(payload.watchList, user.uid))
    );
}
