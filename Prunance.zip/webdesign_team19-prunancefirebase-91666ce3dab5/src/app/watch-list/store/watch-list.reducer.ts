import { watchListsInitialState, WatchListState } from './watch-list.state';
import { WatchListsActions, WatchListsActionTypes } from './watch-list.actions';

export function watchListsReducer(state = watchListsInitialState, action: WatchListsActions): WatchListState {
  switch (action.type) {

    case WatchListsActionTypes.WATCHLISTS_QUERY: {
      return Object.assign({}, state, {
        isLoading: true,
      });
    }

    case WatchListsActionTypes.WATCHLISTS_LOADED: {
      return Object.assign({}, state, {
        watchLists: action.payload.watchLists,
        isLoading: false,
      });
    }

    case WatchListsActionTypes.WATCHLISTS_ERROR: {
      return Object.assign({}, state, {
        isLoading: false,
        error: action.payload.error
      });
    }

    default:
      return state;
  }
}
