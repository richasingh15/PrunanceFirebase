import {createSelector, createFeatureSelector} from '@ngrx/store';
import {WatchListState} from './watch-list.state';

export const getWatchListsState = createFeatureSelector<WatchListState>('watchLists');

export const getWatchLists = createSelector(
    getWatchListsState,
watchLists => watchLists.watchLists
);

export const getIsLoading = createSelector(
    getWatchListsState,
    watchLists => watchLists.isLoading
);

export const getError = createSelector(
    getWatchListsState,
    watchLists => watchLists.error
);
