import { WatchList } from '../models/watch-list.model';

export interface WatchListState {
    watchLists: WatchList[] | null;
    isLoading: boolean;
    error: any;
}

export const watchListsInitialState: WatchListState = {
    watchLists: null,
    isLoading: true,
    error: null
};
