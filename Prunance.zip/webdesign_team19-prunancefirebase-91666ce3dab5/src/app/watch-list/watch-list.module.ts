import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {ButtonsModule, InputsModule, TableModule, IconsModule, ModalModule, CardsModule} from 'angular-bootstrap-md';

import * as fromWatchLists from './store/watch-list.reducer';
import {StoreModule} from '@ngrx/store';
import {EffectsModule} from '@ngrx/effects';
import {WatchListEffects} from './store/watch-list.effects';
import {WatchListRoutingModule} from './watch-list-routing.module';
import {SharedModule} from '../shared/shared.module';
import {WatchListComponent} from './containers/watch-list/watch-list.component';

@NgModule({
    imports: [
        CommonModule,
        SharedModule,
        WatchListRoutingModule,
        ModalModule,
        FormsModule,
        ButtonsModule,
        InputsModule,
        IconsModule,
        TableModule,
        StoreModule.forFeature('watchLists', fromWatchLists.watchListsReducer),
        EffectsModule.forFeature([WatchListEffects]),
        CardsModule
    ],
    declarations: [WatchListComponent],
    exports: [WatchListComponent],
})

export class WatchListModule {
}
